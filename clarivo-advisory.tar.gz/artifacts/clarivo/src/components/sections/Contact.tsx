import { useState } from "react";
import { CheckCircle2, Mail, Phone, ExternalLink } from "lucide-react";
import { FaWhatsapp } from "react-icons/fa";

export function Contact() {
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const name = formData.get("name") as string;
    const company = formData.get("company") as string;
    const projectType = formData.get("projectType") as string;
    const message = formData.get("message") as string;

    const text = `Hi Shiv, my name is ${name} from ${company}. I'm interested in ${projectType}. ${message}`;
    
    setSubmitted(true);
    
    setTimeout(() => {
      window.open(`https://wa.me/917600048237?text=${encodeURIComponent(text)}`, "_blank");
    }, 1500);
  };

  return (
    <section id="contact" className="py-24 bg-navy-mid relative overflow-hidden">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 right-0 w-[40vw] h-[40vw] bg-gold/5 rounded-full blur-[150px] mix-blend-screen" />
      </div>

      <div className="max-w-7xl mx-auto px-6 relative z-10 grid lg:grid-cols-2 gap-16">
        
        {/* Left Col */}
        <div className="animate-in fade-right">
          <h2 className="font-serif text-4xl md:text-5xl text-white mb-4">Start a Conversation</h2>
          <p className="text-xl text-gray-400 font-light mb-12">
            Book a complimentary 30-minute strategy session. No pitch, no pressure — just clarity on what's possible for your business.
          </p>

          <div className="space-y-6 mb-12">
            <a href="mailto:shiv@clarivoadvisory.com" className="flex items-center gap-4 text-white hover:text-gold transition-colors text-lg">
              <div className="w-12 h-12 rounded-full bg-navy-deep border border-white/10 flex items-center justify-center">
                <Mail className="w-5 h-5" />
              </div>
              shiv@clarivoadvisory.com
            </a>
            <a href="tel:+917600048237" className="flex items-center gap-4 text-white hover:text-gold transition-colors text-lg">
              <div className="w-12 h-12 rounded-full bg-navy-deep border border-white/10 flex items-center justify-center">
                <Phone className="w-5 h-5" />
              </div>
              +91-7600048237
            </a>
            <a href="https://linkedin.com/in/shiv-kkumar" target="_blank" rel="noreferrer" className="flex items-center gap-4 text-white hover:text-blue-accent transition-colors text-lg">
              <div className="w-12 h-12 rounded-full bg-navy-deep border border-white/10 flex items-center justify-center">
                <ExternalLink className="w-5 h-5" />
              </div>
              linkedin.com/in/shiv-kkumar
            </a>
          </div>

          <a 
            href="https://wa.me/917600048237?text=Hi%20Shiv%2C%20I%20would%20like%20to%20discuss%20a%20project." 
            target="_blank" 
            rel="noreferrer"
            className="inline-flex items-center gap-3 bg-[#25D366] text-white px-8 py-4 rounded font-bold text-lg hover:bg-[#20bd5a] transition-colors mb-12 shadow-[0_0_20px_rgba(37,211,102,0.3)]"
          >
            <FaWhatsapp size={24} /> Chat on WhatsApp
          </a>

          <div className="space-y-4">
            <div className="glassmorphism p-6 rounded-xl border border-white/10 flex items-center gap-4">
              <span className="text-2xl">⚡</span>
              <div>
                <h4 className="font-bold text-white mb-1">Response Within 24 Hours</h4>
                <p className="text-sm text-gray-400">All enquiries responded to within one business day.</p>
              </div>
            </div>
            <div className="glassmorphism p-6 rounded-xl border border-white/10 border-l-4 border-l-green-500 flex items-center gap-4">
              <div className="w-3 h-3 rounded-full bg-green-500 animate-pulse" />
              <h4 className="font-bold text-gold">Accepting 2 new engagements for Q3 2025</h4>
            </div>
          </div>
        </div>

        {/* Right Col / Form */}
        <div className="animate-in fade-left">
          <div className="glassmorphism rounded-2xl p-8 md:p-10 border border-white/10 shadow-2xl relative overflow-hidden min-h-[600px] flex items-center">
            
            {submitted ? (
              <div className="absolute inset-0 flex flex-col items-center justify-center bg-navy-deep z-20 animate-in fade-in zoom-in duration-500">
                <CheckCircle2 className="w-20 h-20 text-gold mb-6 animate-bounce" />
                <h3 className="font-serif text-3xl text-white mb-2">Thank you!</h3>
                <p className="text-gray-300 text-center px-6">Shiv will be in touch within 24 hours. Redirecting to WhatsApp...</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6 w-full relative z-10">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-xs font-bold tracking-widest text-gray-400 uppercase mb-2">Full Name *</label>
                    <input name="name" required type="text" className="w-full bg-navy-deep border border-white/10 rounded px-4 py-3 text-white focus:outline-none focus:border-gold transition-colors" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold tracking-widest text-gray-400 uppercase mb-2">Company / Organisation</label>
                    <input name="company" type="text" className="w-full bg-navy-deep border border-white/10 rounded px-4 py-3 text-white focus:outline-none focus:border-gold transition-colors" />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-xs font-bold tracking-widest text-gray-400 uppercase mb-2">Email *</label>
                    <input name="email" required type="email" className="w-full bg-navy-deep border border-white/10 rounded px-4 py-3 text-white focus:outline-none focus:border-gold transition-colors" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold tracking-widest text-gray-400 uppercase mb-2">Phone / WhatsApp *</label>
                    <input name="phone" required type="tel" className="w-full bg-navy-deep border border-white/10 rounded px-4 py-3 text-white focus:outline-none focus:border-gold transition-colors" />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold tracking-widest text-gray-400 uppercase mb-2">Project Type</label>
                  <select name="projectType" className="w-full bg-navy-deep border border-white/10 rounded px-4 py-3 text-white focus:outline-none focus:border-gold transition-colors appearance-none cursor-pointer">
                    <option>AI Automation</option>
                    <option>Trade Intelligence</option>
                    <option>FinTech Consulting</option>
                    <option>Market Research / Financial Markets</option>
                    <option>Business Strategy</option>
                    <option>Speaking / Training</option>
                    <option>Other</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold tracking-widest text-gray-400 uppercase mb-2">Budget Range</label>
                  <select name="budget" className="w-full bg-navy-deep border border-white/10 rounded px-4 py-3 text-white focus:outline-none focus:border-gold transition-colors appearance-none cursor-pointer">
                    <option>Under ₹2L</option>
                    <option>₹2L–₹5L</option>
                    <option>₹5L–₹15L</option>
                    <option>₹15L+</option>
                    <option>Prefer to discuss</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold tracking-widest text-gray-400 uppercase mb-2">Message / Project Brief *</label>
                  <textarea name="message" required rows={4} className="w-full bg-navy-deep border border-white/10 rounded px-4 py-3 text-white focus:outline-none focus:border-gold transition-colors resize-none"></textarea>
                </div>

                <button type="submit" className="w-full bg-gold text-navy-deep font-bold py-4 rounded text-lg hover:bg-gold-dark transition-colors gold-glow">
                  Send Enquiry
                </button>
              </form>
            )}
          </div>
        </div>

      </div>
    </section>
  );
}
