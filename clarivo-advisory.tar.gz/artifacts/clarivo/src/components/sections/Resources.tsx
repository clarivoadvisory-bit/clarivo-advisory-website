import { useState } from "react";
import { Download, CheckCircle2 } from "lucide-react";

export function Resources() {
  const [modalOpen, setModalOpen] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [activeResource, setActiveResource] = useState("");

  const resources = [
    {
      id: "01",
      title: "Export Buyer Discovery Framework",
      desc: "A structured methodology for identifying, qualifying and approaching international buyers across GCC, Africa, ASEAN and Europe — built from live export intelligence campaigns.",
      features: ["Target market segmentation model", "Buyer qualification criteria", "Outreach sequencing playbook"]
    },
    {
      id: "02",
      title: "AI Automation Readiness Checklist",
      desc: "40-point diagnostic covering data infrastructure, workflow maturity, team readiness and automation ROI potential — with scoring guidance and priority action plan.",
      features: ["40-point diagnostic framework", "ROI potential scoring model", "Priority automation opportunity map"]
    },
    {
      id: "03",
      title: "CRM Intelligence Playbook",
      desc: "Transform your CRM from a data graveyard into a revenue engine. Lead scoring architecture, pipeline automation, intent signals and executive dashboard design.",
      features: ["Lead scoring model template", "Pipeline automation blueprint", "Executive dashboard framework"]
    },
    {
      id: "04",
      title: "NIFTY Options Automation Blueprint",
      desc: "The architecture behind Clarivo's NIFTY options automation. Regime scoring, VIX kill switches, strike selection logic and risk management — fully explained.",
      features: ["11-regime composite scoring logic", "VIX kill switch configuration", "Delta-optimised strike selection"]
    },
    {
      id: "05",
      title: "SPY / US Markets Automation Blueprint",
      desc: "Structured blueprint for building systematic US equity automation via Interactive Brokers — market scanning, position management, risk controls and execution workflow.",
      features: ["IBKR API integration guide", "SPY/QQQ strategy architecture", "Risk management checklist"]
    },
    {
      id: "06",
      title: "MT5 Automation Checklist",
      desc: "35-point pre-deployment checklist before going live with any MT5 Expert Advisor — covering execution logic, risk controls, session filters and broker compatibility.",
      features: ["35-point pre-deployment checklist", "Broker compatibility matrix", "Live vs demo validation steps"]
    }
  ];

  const handleDownload = (title: string) => {
    setActiveResource(title);
    setSubmitted(false);
    setModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => {
      setModalOpen(false);
    }, 3000);
  };

  return (
    <section id="resources" className="py-24 bg-[#040E1E] relative">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16 animate-in fade-up">
          <h2 className="font-serif text-3xl md:text-5xl text-white mb-4">6 Frameworks You Can Apply Immediately</h2>
          <p className="text-xl text-gray-400 font-light max-w-2xl mx-auto">
            Practical tools and playbooks distilled from real engagements — no theory, no fluff.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {resources.map((res, i) => (
            <div key={res.id} className="glassmorphism p-8 rounded-xl border border-white/10 flex flex-col h-full hover-lift animate-in fade-up" style={{ animationDelay: `${i * 100}ms` }}>
              <div className="text-gold font-serif text-3xl font-bold mb-4 opacity-50">{res.id}</div>
              <h3 className="font-serif text-xl font-bold text-white mb-4">{res.title}</h3>
              <p className="text-sm text-gray-400 leading-relaxed mb-6 flex-grow">{res.desc}</p>
              
              <ul className="space-y-2 mb-8">
                {res.features.map((feat, idx) => (
                  <li key={idx} className="text-xs text-gray-300 flex items-start gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-gold mt-1.5 flex-shrink-0" />
                    {feat}
                  </li>
                ))}
              </ul>

              <button 
                onClick={() => handleDownload(res.title)}
                className="w-full bg-transparent border border-gold text-gold py-3 rounded font-bold hover:bg-gold hover:text-navy-deep transition-colors flex items-center justify-center gap-2 group mt-auto"
              >
                Download Free <Download className="w-4 h-4 group-hover:-translate-y-1 transition-transform" />
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Download Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-navy-deep/80 backdrop-blur-sm animate-in">
          <div className="bg-navy-mid border border-white/10 p-8 rounded-2xl max-w-md w-full shadow-2xl relative">
            <button 
              onClick={() => setModalOpen(false)}
              className="absolute top-4 right-4 text-gray-400 hover:text-white"
            >
              ✕
            </button>
            
            {submitted ? (
              <div className="text-center py-8 animate-in zoom-in">
                <CheckCircle2 className="w-16 h-16 text-green-500 mx-auto mb-4" />
                <h3 className="font-serif text-2xl text-white mb-2">Success</h3>
                <p className="text-gray-300">Your resource is on the way! Check your inbox.</p>
              </div>
            ) : (
              <div>
                <h3 className="font-serif text-2xl text-white mb-2">Get the Framework</h3>
                <p className="text-sm text-gray-400 mb-6">{activeResource}</p>
                
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold tracking-widest text-gray-400 uppercase mb-1">Full Name</label>
                    <input required type="text" className="w-full bg-navy border border-white/10 rounded px-4 py-3 text-white focus:outline-none focus:border-gold transition-colors" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold tracking-widest text-gray-400 uppercase mb-1">Email</label>
                    <input required type="email" className="w-full bg-navy border border-white/10 rounded px-4 py-3 text-white focus:outline-none focus:border-gold transition-colors" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold tracking-widest text-gray-400 uppercase mb-1">Phone</label>
                    <input required type="tel" className="w-full bg-navy border border-white/10 rounded px-4 py-3 text-white focus:outline-none focus:border-gold transition-colors" />
                  </div>
                  <button type="submit" className="w-full bg-gold text-navy-deep font-bold py-4 rounded mt-4 hover:bg-gold-dark transition-colors gold-glow">
                    Send Framework
                  </button>
                </form>
              </div>
            )}
          </div>
        </div>
      )}
    </section>
  );
}
