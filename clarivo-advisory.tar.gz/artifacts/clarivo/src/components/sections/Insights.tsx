import { useState } from "react";
import { ArrowRight, ChevronDown, ChevronUp } from "lucide-react";

export function Insights() {
  const [expanded, setExpanded] = useState(false);

  const mainInsight = {
    tag: "AI Automation",
    title: "Why Most AI Automation Projects Fail — And What to Do Differently",
    excerpt: "The problem isn't the technology. It's the sequencing. Three implementation mistakes that derail AI projects before they deliver value — and the framework to avoid them.",
    meta: "June 2025 · 8 min read"
  };

  const insights = [
    { tag: "NIFTY Automation", title: "Building a NIFTY Options Automation System: Architecture, Regime Scoring & Risk Controls", excerpt: "A practitioner's guide to building production-ready NIFTY options automation — regime composite scoring, VIX kill switches and live Telegram monitoring.", meta: "May 2025 · 12 min read" },
    { tag: "MT5 Automation", title: "XAUUSD Automation on MT5: Markov Regimes, Session Filters and Multi-TP Management", excerpt: "How to build an institutional-grade Gold trading EA on MT5 — Markov classification, session-aware execution, grade filtering and TP1/TP2/TP3 management.", meta: "April 2025 · 10 min read" },
    { tag: "Trade Intelligence", title: "The Export Intelligence Stack: What Data Every Indian Exporter Should Track", excerpt: "From HS code analytics to buyer intent signals — the intelligence layer separating reactive exporters from strategic ones competing globally.", meta: "March 2025 · 6 min read" },
    { tag: "Export Growth", title: "GCC Market Entry for Indian Manufacturers: What Works and What Doesn't", excerpt: "Lessons from multiple GCC market entry engagements — buyer intelligence, relationship protocols and compliance layers that separate successful entries from failed ones.", meta: "February 2025 · 9 min read" },
    { tag: "Fintech", title: "India to UAE Fintech Expansion: Regulatory Map, Market Entry and GTM Strategy", excerpt: "A practitioner's guide to entering the UAE fintech market from India — regulatory frameworks, partnership channels and go-to-market sequencing that works.", meta: "January 2025 · 7 min read" },
    { tag: "IBKR Automation", title: "SPY Options Automation via Interactive Brokers: Building a Systematic US Strategy", excerpt: "How to build a production-ready SPY options automation system via IBKR Python API — from scanner design to execution logic to portfolio-level risk controls.", meta: "December 2024 · 11 min read" },
    { tag: "AI Automation", title: "The AI Agent Stack: Which Tools Are Actually Production-Ready in 2025", excerpt: "Cutting through the noise — an honest assessment of which AI agent frameworks, automation platforms and integration tools are ready for real business deployment.", meta: "November 2024 · 7 min read" }
  ];

  const moreTopics = [
    { tag: "MT5", title: "MQL5 Expert Advisor Architecture: From Strategy Logic to Live Deployment" },
    { tag: "NIFTY", title: "NIFTY Options: Why Most Retail Traders Fail and What Automation Solves" },
    { tag: "EURUSD", title: "EURUSD Automation: Session Analysis, Entry Logic and Risk Management on MT5" },
    { tag: "Trade Intelligence", title: "How to Use HS Code Data to Find Your Best Export Markets" },
    { tag: "Interactive Brokers", title: "IBKR Python API: Building Your First Automated Trading System" },
    { tag: "BANK NIFTY", title: "BANK NIFTY OI Flow Analysis: How to Read Open Interest for Options Trading" },
    { tag: "XAUUSD", title: "Gold Trading Automation: Why Regime Detection Changes Everything" },
    { tag: "Export Growth", title: "Africa Market Intelligence: Finding B2B Buyers in Nigeria, Kenya and Ghana" },
    { tag: "Fintech", title: "Building Compliance Into Product Architecture — Not Bolting It On Later" },
    { tag: "SPY", title: "SPY Options Automation: Building a Systematic US Equity Strategy via IBKR" },
    { tag: "Risk Management", title: "Position Sizing for Options Traders: Why Fixed Lots Kill Accounts" },
    { tag: "AI Automation", title: "The AI Automation Stack Every Indian SME Should Build in 2025" }
  ];

  return (
    <section id="insights" className="py-24 bg-white relative">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16 animate-in fade-up">
          <h2 className="font-serif text-4xl md:text-5xl text-navy-deep mb-4">Intelligence for Business Leaders & Traders</h2>
          <p className="text-xl text-gray-600 font-light max-w-2xl mx-auto">
            Practical perspectives on AI, trade, fintech and financial markets — written by Shiv Kumar from 25+ years in the field.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8 mb-16">
          {/* Main Featured */}
          <div className="lg:col-span-2 bg-navy-deep text-white p-8 md:p-12 rounded-2xl hover-lift animate-in fade-up">
            <div className="bg-white/10 text-gold px-3 py-1 rounded-full text-xs font-bold tracking-widest uppercase inline-block mb-6">
              {mainInsight.tag}
            </div>
            <h3 className="font-serif text-3xl md:text-4xl font-bold mb-6 leading-tight">{mainInsight.title}</h3>
            <p className="text-gray-300 text-lg leading-relaxed mb-8">{mainInsight.excerpt}</p>
            <div className="flex items-center justify-between border-t border-white/10 pt-6">
              <span className="text-sm text-gray-400 font-medium">{mainInsight.meta}</span>
              <a href="#contact" className="flex items-center gap-2 text-gold font-bold hover:text-white transition-colors">
                Read article <ArrowRight className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Side Small */}
          <div className="flex flex-col justify-between gap-8">
            {insights.slice(0, 2).map((ins, i) => (
              <div key={i} className="bg-gray-50 border border-gray-100 p-6 rounded-2xl hover-lift h-full flex flex-col justify-between animate-in fade-up">
                <div>
                  <div className="text-navy-deep font-bold text-xs tracking-widest uppercase mb-3">{ins.tag}</div>
                  <h3 className="font-serif text-xl font-bold text-navy-deep mb-3 leading-snug">{ins.title}</h3>
                  <p className="text-sm text-gray-600 line-clamp-3 mb-4">{ins.excerpt}</p>
                </div>
                <div className="flex items-center justify-between mt-auto">
                  <span className="text-xs text-gray-500 font-medium">{ins.meta}</span>
                  <a href="#contact" className="text-gold font-bold text-sm hover:text-navy-deep transition-colors">Read →</a>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Grid Smaller */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {insights.slice(2).map((ins, i) => (
            <div key={i} className="bg-white border border-gray-200 p-6 rounded-2xl hover:border-gold hover-lift flex flex-col justify-between animate-in fade-up">
               <div>
                  <div className="text-navy-deep font-bold text-xs tracking-widest uppercase mb-3">{ins.tag}</div>
                  <h3 className="font-serif text-lg font-bold text-navy-deep mb-3 leading-snug">{ins.title}</h3>
                  <p className="text-sm text-gray-600 line-clamp-2 mb-4">{ins.excerpt}</p>
                </div>
                <div className="flex items-center justify-between mt-auto pt-4 border-t border-gray-100">
                  <span className="text-xs text-gray-500 font-medium">{ins.meta}</span>
                  <a href="#contact" className="text-gold font-bold text-sm hover:text-navy-deep transition-colors">Read →</a>
                </div>
            </div>
          ))}
        </div>

        {/* Expandable Topics */}
        <div className="border-t border-gray-200 pt-8 animate-in fade-up">
          <button 
            onClick={() => setExpanded(!expanded)}
            className="w-full flex items-center justify-between text-left text-xl font-serif text-navy-deep font-bold hover:text-gold transition-colors"
          >
            More from the Clarivo Intelligence Brief — 50 Topics
            {expanded ? <ChevronUp className="w-6 h-6" /> : <ChevronDown className="w-6 h-6" />}
          </button>
          
          <div className={`grid md:grid-cols-2 gap-x-8 gap-y-4 overflow-hidden transition-all duration-500 ${expanded ? 'max-h-[1000px] mt-8 opacity-100' : 'max-h-0 opacity-0'}`}>
             {moreTopics.map((topic, i) => (
               <a key={i} href="#contact" className="group flex items-start gap-4 p-3 hover:bg-gray-50 rounded-lg transition-colors border border-transparent hover:border-gray-100">
                 <div className="bg-navy-deep/5 text-navy-deep px-2 py-1 rounded text-[10px] font-bold tracking-widest uppercase flex-shrink-0 mt-1 w-24 text-center">
                   {topic.tag}
                 </div>
                 <div className="text-sm font-bold text-gray-700 group-hover:text-navy-deep transition-colors leading-snug">
                   {topic.title} <span className="text-gold ml-1">→</span>
                 </div>
               </a>
             ))}
          </div>
        </div>

      </div>
    </section>
  );
}
